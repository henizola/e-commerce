import React, { Component } from "react";
import "./Navbar.css";
import { FaSearch, FaRegUser, FaRegHeart, FaShoppingBag } from "react-icons/fa";

export default class Navbar extends Component {
  render() {
    return (
      <nav className="navbar fixed-top">
        <div className="container-fluid">
          <div className="navbar_logo_wrapper">
            <img
              src="/images/logo/logo-white.png"
              alt=""
              className="navbar_logo_img"
            />
          </div>
          <ul className="rightsidenav">
            <li className="rightsidenav_item">
              <a href="" className="rightsidenav_item_link">
                {/* <span className="icon search_nav"></span> */}
                <FaSearch className="navbar_icons" />
              </a>
            </li>
            <li className="rightsidenav_item">
              <a href="" className="rightsidenav_item_link">
                {/* <span className="icon search_nav"></span> */}
                <FaRegUser className="navbar_icons" />
              </a>
            </li>
            <li className="rightsidenav_item">
              <a href="" className="rightsidenav_item_link">
                {/* <span className="icon search_nav"></span> */}
                <FaRegHeart className="navbar_icons" />
              </a>
            </li>
            <li className="rightsidenav_item">
              <a href="" className="rightsidenav_item_link">
                {/* <span className="icon search_nav"></span> */}
                <FaShoppingBag className="navbar_icons" />
              </a>
            </li>
          </ul>
        </div>
      </nav>
    );
  }
}
