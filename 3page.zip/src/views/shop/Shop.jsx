import React, { Component } from "react";
import "./Shop.css";

class Shop extends Component {
  render() {
    return (
      <div>
        Shop Listing
      </div>
    );
  }
}

export default Shop;
