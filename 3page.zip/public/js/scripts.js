function showOrange1() {
    var x = document.getElementById("orange1");
    var y = document.getElementById("orange2");
    var z = document.getElementById("orange3");
    x.style.display = "block";
    y.style.display = "none";
    z.style.display = "none";
}

function showOrange2() {
    var x = document.getElementById("orange1");
    var y = document.getElementById("orange2");
    var z = document.getElementById("orange3");
    x.style.display = "none";
    y.style.display = "block";
    z.style.display = "none";
}

function showOrange3() {
    var x = document.getElementById("orange1");
    var y = document.getElementById("orange2");
    var z = document.getElementById("orange3");
    x.style.display = "none";
    y.style.display = "none";
    z.style.display = "block";
}

function showGreen1() {
    var x = document.getElementById("green1");
    var y = document.getElementById("green2");
    var z = document.getElementById("green3");
    x.style.display = "block";
    y.style.display = "none";
    z.style.display = "none";
}

function showGreen2() {
    var x = document.getElementById("green1");
    var y = document.getElementById("green2");
    var z = document.getElementById("green3");
    x.style.display = "none";
    y.style.display = "block";
    z.style.display = "none";
}

function showGreen3() {
    var x = document.getElementById("green1");
    var y = document.getElementById("green2");
    var z = document.getElementById("green3");
    x.style.display = "none";
    y.style.display = "none";
    z.style.display = "block";
}

function showGreen() {
    var a = document.getElementById("green_main");
    var b = document.getElementById("green_list");
    var c = document.getElementById("orange_main");
    var d = document.getElementById("orange_list");
    a.style.display = "block";
    b.style.display = "block";
    c.style.display = "none";
    d.style.display = "none";
}

function showOrange() {
    var a = document.getElementById("green_main");
    var b = document.getElementById("green_list");
    var c = document.getElementById("orange_main");
    var d = document.getElementById("orange_list");
    a.style.display = "none";
    b.style.display = "none";
    c.style.display = "block";
    d.style.display = "block";
}